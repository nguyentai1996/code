package com.example.demovoley;

public class retrofit {
    public  static PolyService polyService;
    public  static PolyService getInstent;


}
